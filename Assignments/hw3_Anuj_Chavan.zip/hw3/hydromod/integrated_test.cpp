// integrated_test.cpp
#include "init.h"
#include "eigenval.h"
#include "output.h"
#include <catch2/catch_all.hpp>
#include <fstream>
#include <cstdio>
#include "rarray"

TEST_CASE("Integrated Test for hydrogen") {
    // Initializing the matrix
    int n = 27; // A valid value (third power of an odd number)
    rmatrix<double> H = initMatrix(n);
    
    REQUIRE(H.extent(0) > 0); // Checking matrix is not empty
    REQUIRE(H.extent(0) == H.extent(1)); // Checking for  square matrix

    // Computing the eigenvalues
    double e;               // Eigenvalue
    rvector<double> a(n);   // Eigenvector
    REQUIRE_NOTHROW(groundState(H, e, a)); // Ensure function does not fail

    REQUIRE(a.size() == n); // Ensure eigenvector has correct size

    // Writing to output bin file
    std::string filename = "test_output.bin";
    writeBinary(filename, a);

    // Verifying output file exists
    std::ifstream file(filename, std::ios::binary);
    REQUIRE(file.is_open());

    // Removing test file
    file.close();
    std::remove(filename.c_str());

    
    // Writing to output txt file
    std::string filename_txt = "test_output.txt";
    writeText(filename_txt, a);

    // Verifying output txt file exists
    std::ifstream file_txt(filename_txt);
    REQUIRE(file_txt.is_open());

    // Removing txt test file
    file_txt.close();
    std::remove(filename_txt.c_str());
}
