#define CATCH_CONFIG_MAIN
#include <catch2/catch_all.hpp>
#include "eigenval.h"

// Test case for given matrix {{-1,1},{2,0}}; expected to pass for value = -2.0
TEST_CASE("Ground State Test: Matrix {{-1,1},{2,0}}") {
    rmatrix<double> m(2,2);
    m[0][0] = -1; m[0][1] = 1;
    m[1][0] = 2;  m[1][1] = 0;

    double eigenvalue;
    rvector<double> eigenvector(2);

    REQUIRE_NOTHROW(groundState(m, eigenvalue, eigenvector)); // Computes without errors
    REQUIRE(eigenvalue == Catch::Approx(-2.0)); // Expected -2
}

// Test case for identity matrix; expected to fail for value = 1.0
TEST_CASE("Ground State Test: 2x2 Identity matrix") {
    rmatrix<double> m(2,2);
    m[0][0] = 1; m[0][1] = 0;
    m[1][0] = 0; m[1][1] = 1;
    
    double eigenvalue;
    rvector<double> eigenvector(2);

    REQUIRE_NOTHROW(groundState(m, eigenvalue, eigenvector)); // Computes without errors
    REQUIRE(eigenvalue == Catch::Approx(1.0)); // Expected 1 but answers 0 (error in source files)
}

// Test case for identity matrix; expected to fail for value = 1.0
TEST_CASE("Ground State Test: 3x3 Identity matrix") {
    rmatrix<double> m(3,3);
    m[0][0] = 1; m[0][1] = 0; m[0][2] = 0;
    m[1][0] = 0; m[1][1] = 1; m[1][2] = 0;
    m[2][0] = 0; m[2][1] = 0; m[2][2] = 1;
    
    double eigenvalue;
    rvector<double> eigenvector(2);

    REQUIRE_NOTHROW(groundState(m, eigenvalue, eigenvector)); // Computes without errors
    REQUIRE(eigenvalue == Catch::Approx(1.0)); // Expected 1 but answers 0 (error in source files)
}

// Test case for diagonal matrix; expected to pass for min of diagonal elements
TEST_CASE("Ground State Test: Diagonal matrix") {
    rmatrix<double> m(3,3);
    m[0][0] = 8;  m[0][1] = 0;  m[0][2] = 0;
    m[1][0] = 0;  m[1][1] = -5; m[1][2] = 0;
    m[2][0] = 0;  m[2][1] = 0;  m[2][2] = 2;
    
    double eigenvalue;
    rvector<double> eigenvector(3);

    REQUIRE_NOTHROW(groundState(m, eigenvalue, eigenvector)); // Computes without errors
    REQUIRE(eigenvalue == Catch::Approx(-5.0));  // Expected mallest element = -5
}

// Test case for  matrix; expected to fail execution
TEST_CASE("Ground State Test: Matrix {{1,1},{2,0}}") {
    rmatrix<double> m(2,2);
    m[0][0] = 1; m[0][1] = 1;
    m[1][0] = 2; m[1][1] = 0;
    
    double eigenvalue;
    rvector<double> eigenvector(2);

    REQUIRE_THROWS(groundState(m, eigenvalue, eigenvector)); // Throws an error
}