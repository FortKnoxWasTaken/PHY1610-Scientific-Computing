// output_test.cpp
#include "output.h"
#include <fstream>
#include <cstdio>

#include <catch2/catch_all.hpp>

// Check if writeText function works
TEST_CASE("writeText Test")
{
    // create file:
    rvector<double> a(3);
    a = 1,2,3;
    writeText("testoutputarr.txt", a);
    
    // read back:
    std::ifstream in("testoutputarr.txt");
    std::string s[3];
    in >> s[0] >> s[1] >> s[2];
    
    // check
    REQUIRE(s[0]=="1");
    REQUIRE(s[1]=="2");
    REQUIRE(s[2]=="3");

    in.close();
    std::remove("testoutputarr.txt");  // Delete file after test
}


// Check if writeBinary function works
TEST_CASE("writeBinary Test")
{
    rvector<double> a(3);
    a = 1.0, 2.0, 3.0;  // Set values
    writeBinary("testoutputarr.bin", a);

    std::ifstream in("testoutputarr.bin", std::ios::binary);
    double val;
    rvector<double> b(3);

    for (int i = 0; i < 3; i++) {
        in.read(reinterpret_cast<char*>(&val), sizeof(val));
        b[i] = val;
    }

    REQUIRE(b[0] == 1.0);
    REQUIRE(b[1] == 2.0);
    REQUIRE(b[2] == 3.0);

    in.close();
    std::remove("testoutputarr.bin");  // Delete file after test
}