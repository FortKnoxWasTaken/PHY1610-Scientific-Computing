// init_test.cpp
#include "init.h"
#include <catch2/catch_all.hpp>
#include <iostream>

// Test for n = 1
TEST_CASE("initMatrix Test: n=1") {
    int n = 1;
    rmatrix<double> matrix = initMatrix(n);
    
    REQUIRE(matrix.extent(0) == 1);  // Expected matrix size = 1x1
    REQUIRE(matrix[0][0] == Catch::Approx(-97.0/2500.0));  // The matrix element should be (-97/2500)
}

// Test for n = 27 
TEST_CASE("initMatrix Test: n=27") {
    int n = 27;
    rmatrix<double> matrix = initMatrix(n);
    
    REQUIRE(matrix.extent(0) == n);  // Expected matrix size = 27x27
}

// Test for n = 125
TEST_CASE("initMatrix Test: n=125") {
    int n = 125;
    rmatrix<double> matrix = initMatrix(n);
    
    REQUIRE(matrix.extent(0) == n);  // Expected matrix size = 125x125
}

// Testing that function returns an empty matrix when n is 0
TEST_CASE("initMatrix Test: n=0") {
    int n = 0;
    rmatrix<double> matrix = initMatrix(n);
    
    REQUIRE(matrix.extent(0) == 0);  // require empty matrix
}

// Testing that the function does not work for n /= cube of an odd number
TEST_CASE("initMatrix Test: invalid n=100 (non-cube odd)") {
    int n = 100;
    REQUIRE_THROWS(initMatrix(n));  // require empty matrix
}

