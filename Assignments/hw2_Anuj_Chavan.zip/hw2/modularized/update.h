// update header file

#ifndef UPDATE_H
#define UPDATE_H

#include "rarray"

// update_cell function template
void update_cells(rvector<bool>& alive_status);

#endif
