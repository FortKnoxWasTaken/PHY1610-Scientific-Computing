// output header file

#ifndef OUTPUT_H
#define OUTPUT_H

#include "rarray"

// output_cells function template
void output_cells(const rvector<bool>& alive_status, int step);

#endif